# Super secret file repository

This zip file contains super secret files, protected by our most advanced encryption systems.
These should never be leaked to the public because it may cause our company to shut down.

## Our evil goals

As described by the conveniently placed evidence which nobody will ever read, our plans are evil.

## If somebody gets the files

Yeah, we're done for. But fortunately, if somebody steals only this file, we should be fine. Probably.
